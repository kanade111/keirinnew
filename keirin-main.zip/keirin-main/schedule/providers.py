"""Schedule providers for automatic race discovery."""
from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Callable, List, Optional
from urllib.request import Request, urlopen
from utils import get_logger

import pandas as pd

logger = get_logger(__name__)

RACE_ID_PATTERN = re.compile(r"(\d{8}\w{2}\d{2})")


# =========================
#  Generic Provider Class
# =========================
@dataclass
class Provider:
    name: str
    url_builder: Callable[[str], str]

    def fetch(self, date_str: str) -> str:
        url = self.url_builder(date_str)
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            )
        }
        req = Request(url, headers=headers)
        with urlopen(req, timeout=15) as resp:
            data = resp.read()
            enc = resp.headers.get_content_charset() or "utf-8"
        return data.decode(enc, errors="ignore")

    def extract(self, text: str) -> List[str]:
        return sorted(set(RACE_ID_PATTERN.findall(text)))

    def list_race_ids(self, date_str: str) -> List[str]:
        try:
            text = self.fetch(date_str)
        except Exception as exc:
            logger.warning("Provider %s failed: %s", self.name, exc)
            return []
        race_ids = self.extract(text)
        logger.info("Provider %s yielded %d race ids", self.name, len(race_ids))
        return race_ids


# =========================
#  Built-in Providers
# =========================
KdreamsProvider = Provider(
    name="kdreams",
    url_builder=lambda date_str: f"https://keirin.kdreams.jp/gamboo/keirin-kaisai/schedule/{date_str.replace('-', '')}",
)

KeirinJpProvider = Provider(
    name="keirin_jp",
    url_builder=lambda date_str: f"https://keirin.jp/pc/racecalendar?date={date_str.replace('-', '')}",
)


# =========================
#  Chariloto Provider (New)
# =========================
class CharilotoProvider:
    """Fetch race ids from chariloto.com"""

    name = "chariloto"
    base_url = "https://www.chariloto.com/keirin/results"

    # 主な開催バンクコード（01~47など必要に応じて拡張）
    bank_codes = [f"{i:02d}" for i in range(1, 48)]

    def _fetch_html(self, url: str) -> str:
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            )
        }
        req = Request(url, headers=headers)
        with urlopen(req, timeout=15) as resp:
            data = resp.read()
            enc = resp.headers.get_content_charset() or "utf-8"
        return data.decode(enc, errors="ignore")

    def list_race_ids(self, date_str: str) -> List[str]:
        race_ids: List[str] = []
        y, m, d = date_str.split("-")
        for bank in self.bank_codes:
            url = f"{self.base_url}/{bank}/{y}-{m}-{d}"
            try:
                html = self._fetch_html(url)
                if "決まり手" not in html and "着" not in html:
                    continue
                # Charilotoではレース数を結果ページ内の「第xxレース」で判定
                matches = re.findall(r"第\s*(\d+)\s*レース", html)
                for rnum in sorted(set(matches)):
                    rid = f"{y}{m}{d}CL{bank}{int(rnum):02d}"
                    race_ids.append(rid)
                time.sleep(0.3)
            except Exception as e:
                logger.warning(f"Chariloto fetch failed for {bank}: {e}")
        logger.info("Provider chariloto yielded %d race ids for %s", len(race_ids), date_str)
        return race_ids


# =========================
#  Unified Race ID Collector
# =========================
def list_race_ids_for_date(
    date_str: str,
    venues: Optional[List[str]] = None,
    providers: str = "chariloto,kdreams,keirin_jp",
) -> List[str]:
    provider_map = {
        "chariloto": CharilotoProvider(),
        "kdreams": KdreamsProvider,
        "keirin_jp": KeirinJpProvider,
    }
    selected = [p.strip() for p in providers.split(",") if p.strip()]
    results: List[str] = []

    for name in selected:
        provider = provider_map.get(name)
        if not provider:
            continue
        race_ids = provider.list_race_ids(date_str)
        if venues:
            race_ids = [rid for rid in race_ids if any(v in rid for v in venues)]
        if race_ids:
            results.extend(race_ids)

    return sorted(set(results))
