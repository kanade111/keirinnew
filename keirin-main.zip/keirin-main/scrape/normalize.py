# -*- coding: utf-8 -*-
"""Normalization helpers for scraped data."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Union

import pandas as pd  # DataFrame対応
from utils import ensure_directory, get_logger

logger = get_logger(__name__)

# -------------------------
# Defaults (missing-safe)
# -------------------------
ENTRY_DEFAULTS: Dict[str, str] = {
    "race_id": "",
    "date": "",
    "race_no": "",
    "stadium": "",
    "track": "",
    "class": "",
    "grade": "",
    "lane_no": "",
    "rider_id": "",
    "rider_name": "",
    "score": "",
    "style": "",
    "backs": "0",
    "homes": "0",
    "starts": "0",
    "win_rate": "0",
    "quinella_rate": "0",
    "top3_rate": "0",
    "kimarite_nige": "0",
    "kimarite_makuri": "0",
    "kimarite_sashi": "0",
    "kimarite_mark": "0",
    "finish_pos": "",
    "age": "",
    "prefecture": "",
    "gear": "",
    "term": "",
    "line_id": "",
    "line_pos": "",
    "bank_code": "",
    "source": "",
}

INFO_DEFAULTS: Dict[str, str] = {
    "race_id": "",
    "date": "",
    "race_no": "",
    "stadium": "",
    "track": "",
    "title": "",
    "race_name": "",
    "grade": "",
    "start_time": "",
    "weather": "",
    "wind": "",
    "kaizai_no": "",
    "field_size": "",
    "line_count": "",
    "line_pattern": "",
    "bank_code": "",
    "source": "",
}

# 既定の出力カラム順（存在しない列は空で埋める）
TRAINING_COLUMNS_ORDER: List[str] = [
    "race_id",
    "date",
    "race_no",
    "stadium",
    "track",
    "title",
    "race_name",
    "grade",
    "class",
    "lane_no",
    "rider_id",
    "rider_name",
    "age",
    "prefecture",
    "score",
    "style",
    "backs",
    "homes",
    "starts",
    "win_rate",
    "quinella_rate",
    "top3_rate",
    "kimarite_nige",
    "kimarite_makuri",
    "kimarite_sashi",
    "kimarite_mark",
    "finish_pos",
    "line_id",
    "line_pos",
    "gear",
    "bank_code",
    "source",
    "field_size",
    "line_count",
    "line_pattern",
]
CARDS_COLUMNS_ORDER: List[str] = [c for c in TRAINING_COLUMNS_ORDER if c != "finish_pos"]


# -------------------------
# Small utilities
# -------------------------
def _as_rows(obj: Union[pd.DataFrame, Sequence[Dict[str, str]]]) -> List[Dict[str, str]]:
    """Accept DataFrame or iterable of dicts and return list[dict]."""
    if isinstance(obj, pd.DataFrame):
        return obj.to_dict(orient="records")
    # already sequence of dicts
    return [dict(r) for r in obj]


def _normalize_row(row: Dict[str, str], defaults: Dict[str, str]) -> Dict[str, str]:
    normalized = dict(defaults)
    for k, v in row.items():
        if v is None:
            continue
        normalized[k] = str(v)
    return normalized


def _write_csv(path: str | Path, rows: List[Dict[str, str]], columns: Optional[List[str]] = None) -> None:
    """Write rows (list of dict) to CSV. If columns is given, fix the order."""
    if not rows:
        return
    ensure_directory(Path(path).parent)
    # decide headers
    if columns:
        headers = list(columns)
        # 足りない列は後方に追加
        seen = set(headers)
        for r in rows:
            for k in r.keys():
                if k not in seen:
                    headers.append(k)
                    seen.add(k)
    else:
        headers = list(rows[0].keys())

    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(",".join(headers) + "\n")
        for r in rows:
            f.write(",".join(str(r.get(h, "")) for h in headers) + "\n")


# -------------------------
# Public APIs
# -------------------------
def to_training_csv(
    entry_rows: Union[pd.DataFrame, Sequence[Dict[str, str]]],
    info_rows: Union[pd.DataFrame, Sequence[Dict[str, str]]],
    payout_rows: Union[pd.DataFrame, Sequence[Dict[str, str]]],  # 使わないが将来拡張用に保持
    out_path: str,
) -> None:
    """学習用CSV（races.csv）を書き出し。entry+info を1行に結合して既定列順で出力。"""
    entry_list = _as_rows(entry_rows)
    info_list = _as_rows(info_rows)

    # race_id -> info（正規化）
    info_map: Dict[str, Dict[str, str]] = {}
    for info in info_list:
        rid = str(info.get("race_id", ""))
        if not rid:
            continue
        info_map[rid] = _normalize_row(info, INFO_DEFAULTS)

    enriched: List[Dict[str, str]] = []
    for row in entry_list:
        rid = str(row.get("race_id", ""))
        entry_norm = _normalize_row(row, ENTRY_DEFAULTS)
        info_norm = info_map.get(rid, dict(INFO_DEFAULTS))
        combined = dict(info_norm)
        combined.update(entry_norm)
        # 補完
        if not combined.get("track") and combined.get("stadium"):
            combined["track"] = combined.get("stadium", "")
        if not combined.get("date"):
            combined["date"] = entry_norm.get("date", "")
        enriched.append(combined)

    if not enriched:
        logger.warning("to_training_csv: no rows to write for %s", out_path)
        return

    _write_csv(out_path, enriched, TRAINING_COLUMNS_ORDER)
    logger.info("Training CSV written to %s", out_path)


def to_cards_csv(
    entry_rows: Union[pd.DataFrame, Sequence[Dict[str, str]]],
    out_path: str,
) -> None:
    """推論用CSV（cards.csv）。finish_pos を落として既定列順で出力。"""
    entry_list = _as_rows(entry_rows)

    cards: List[Dict[str, str]] = []
    for row in entry_list:
        entry_norm = _normalize_row(row, ENTRY_DEFAULTS)
        entry_norm.pop("finish_pos", None)
        cards.append(entry_norm)

    if not cards:
        logger.warning("to_cards_csv: no rows to write for %s", out_path)
        return

    _write_csv(out_path, cards, CARDS_COLUMNS_ORDER)
    logger.info("Cards CSV written to %s", out_path)
